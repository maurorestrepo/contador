# Contador avanzado de visitas en PHP 
 Contador de visitas en PHP avanzado con dashboard que muestra visitas y visitantes de hoy además de gráficas por período de tiempo. Este programa registra las visitas a nuestra página web, así como la cantidad de visitantes.

 También muestra las páginas más vistas en una fecha, y las visitas que ha tenido una página específica en un rango de fechas.
 ![Dashboard - Contador de visitas en PHP y MySQL](https://parzibyte.me/blog/wp-content/uploads/2021/03/Reporte-de-visitas-y-visitantes-en-PHP-Contador-de-visitas-web.png)

# Tutorial e instalación
En el blog de Parzibyte: https://parzibyte.me/blog/2021/03/01/php-contador-visitas-avanzado-graficas-reporte/