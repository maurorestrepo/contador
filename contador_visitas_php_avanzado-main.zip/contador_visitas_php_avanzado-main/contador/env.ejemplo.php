; <?php exit; ?>
MYSQL_DATABASE_NAME = "visitas_php"
MYSQL_USER = "root"
MYSQL_PASSWORD = ""